/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;

import javafx.fxml.FXML;

/**
 *
 * @author ALVARO ANDRES
 */
public class TiendaControlador {

    @FXML
    public void initialize() {
        System.out.println("Tienda iniciada");
    }

}
